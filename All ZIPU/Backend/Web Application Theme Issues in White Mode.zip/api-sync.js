/* Replace mock-only form handlers with the Python API while keeping the supplied UI. */
(async function(){
  try { await window.CYCLONEX.ready; } catch (error) { if (document.body.dataset.page !== 'login') window.ravenToast?.(error.message, 'error'); }
  const refresh = async () => { try { const data = await window.api('/api/bootstrap'); window.RAVEN_DATA = data; ['renderMetrics','renderWeather','renderZones','renderLatestBroadcast','renderFeed','renderReports','renderBroadcastHistory','renderProfile','renderNodes','renderMessages','renderSOS'].forEach(name => window[name]?.()); } catch (_) {} };
  document.addEventListener('submit', async event => {
    const form = event.target; let path = null; let payload = null;
    if (form.id === 'broadcast-form') { path='/api/broadcasts'; const d=new FormData(form); payload=Object.fromEntries(d); }
    if (form.id === 'report-form') { path='/api/reports'; const d=new FormData(form); payload=Object.fromEntries(d); payload.photo=payload.photo?.name||''; }
    if (form.id === 'profile-form') { path='/api/profile'; const d=new FormData(form); payload=Object.fromEntries(d); payload.contacts=window.collectContacts?.()||[]; }
    if (form.id === 'chat-form') { path='/api/messages'; const d=new FormData(form); payload={nodeId:window.selectedNode?.id||'',text:d.get('message')}; }
    if (!path) return;
    event.preventDefault(); event.stopImmediatePropagation();
    try { await window.api(path,{method:path==='/api/profile'?'PUT':'POST',body:JSON.stringify(payload)}); form.reset(); await refresh(); window.ravenToast?.('Saved to the CycloneX response network'); } catch(error) { window.ravenToast?.(error.message,'error'); }
  }, true);
  document.addEventListener('click', async event => {
    const button=event.target.closest('#send-sos,#cancel-sos,#logout'); if(!button) return;
    if(button.id==='send-sos'){ event.preventDefault(); event.stopImmediatePropagation(); const form=document.getElementById('sos-form'); const d=new FormData(form); let coords=''; try{coords=await new Promise((resolve,reject)=>navigator.geolocation.getCurrentPosition(p=>resolve(`${p.coords.latitude.toFixed(4)}, ${p.coords.longitude.toFixed(4)}`),reject,{timeout:4000}));}catch(_){} try{await window.api('/api/sos',{method:'POST',body:JSON.stringify({note:d.get('note'),meeting:d.get('meeting'),coords})}); await refresh(); window.ravenToast?.('SOS signal sent to the response network','error');}catch(error){window.ravenToast?.(error.message,'error');} }
    if(button.id==='cancel-sos'){ event.preventDefault(); event.stopImmediatePropagation(); try{await window.api('/api/sos',{method:'DELETE'}); await refresh(); window.ravenToast?.('SOS signal withdrawn');}catch(error){window.ravenToast?.(error.message,'error');} }
    if(button.id==='logout'){ event.preventDefault(); event.stopImmediatePropagation(); await window.api('/api/logout',{method:'DELETE'}); window.location='login.html'; }
  }, true);
})();
window.collectContacts = function(){ return [...document.querySelectorAll('[data-contact-name]')].map((x,i)=>({name:x.value.trim(),phone:document.querySelector(`[data-contact-phone="${i}"]`)?.value.trim()||''})).filter(c=>c.name||c.phone); };
