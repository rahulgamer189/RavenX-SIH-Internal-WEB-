# CycloneX Disaster Intelligence

CycloneX is a Python-backed cyclone and disaster-response dashboard that combines seeded satellite-map layers, forecast-track confidence, field reports, broadcasts, SOS signals, and authenticated responder coordination.

## Run & Operate

- `npm run dev` — run the Python API and static web app (port 5000)
- `PORT=5000 BASE_PATH=/__mockup npm run build` — full workspace build when the mockup artifact is included
- `pnpm --filter @workspace/api-server run dev` — same server through the workspace workflow
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Optional env: `SESSION_SECRET` — changes the default local session fallback
- Optional env: `COOKIE_SECURE=1` — enables secure cookies when served over HTTPS

## Stack

- Python 3.13 standard library HTTP server
- SQLite persistence for the runnable demo
- Leaflet 1.9.4, OpenStreetMap and Esri World Imagery layers
- The uploaded vanilla HTML/CSS/JS UI is served directly from `artifacts/api-server/static`

## Where things live

- `artifacts/api-server/main.py` — Python HTTP API, SQLite schema, seeded accounts, sessions and API handlers
- `artifacts/api-server/static/` — CycloneX web UI, map, auth screen and browser behavior
- `artifacts/api-server/data/cyclonex.db` — created on first run; local demo persistence

## Architecture decisions

- The backend intentionally uses only the Python standard library so a clean checkout can run with `npm run dev` without a Python virtual environment.
- The UI is served same-origin with the API, so browser requests use relative `/api/...` paths and session cookies work in VS Code/Replit previews.
- Demo credentials are seeded into SQLite on first run; the password hashes, not plaintext passwords, are stored.
- Map base layers are switchable between OpenStreetMap and public Esri World Imagery; both require their provider attribution.

## Product

- Login with Authority or Responder demo roles
- Command dashboard with risk zones, rainfall, weather and a unified activity feed
- Leaflet operational map with SOS, shelter, danger-zone, rainfall and forecast-track layers
- Authenticated broadcast publishing, field reports, SOS submit/withdraw, responder messages and profile editing

## User preferences

- Keep the backend Python-first; use the existing HTML/CSS/JS only as the thin browser client.

## Gotchas

- Demo weather, hazards and forecast values are seeded data until a provider adapter is connected.
- Real-world release requires provider terms/attribution, verified emergency integrations, production database, TLS, monitoring, privacy controls and domain-specific authorization.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
