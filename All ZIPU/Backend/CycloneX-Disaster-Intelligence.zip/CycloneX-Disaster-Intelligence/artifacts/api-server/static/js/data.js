/* Mock data loader bridge. The actual dataset lives in data/mock-data.js for maintainability. */
if(!window.RAVEN_DATA){
  window.RAVEN_DATA={weather:{temp:29,feels:31,condition:"Partly cloudy",humidity:78,wind:18,rainChance:72,forecast:[]},zones:[],sos:[],shelters:[],nearby:[],broadcasts:[],reports:[],feed:[]};
}
