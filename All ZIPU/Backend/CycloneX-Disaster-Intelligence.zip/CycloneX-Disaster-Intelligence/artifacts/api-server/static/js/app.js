/* CycloneX shell, API client, session guard and shared navigation. */
(function(){
  const page=document.body.dataset.page||"dashboard";
  const nav=[
    ["dashboard.html","Dashboard","dashboard"],["map.html","Live Map","map"],["broadcast.html","Broadcast","broadcast"],
    ["field-reports.html","Reports","reports"],["chat.html","Network","chat"],["profile.html","Profile","profile"]
  ];
  const root=document.documentElement;
  window.api=async function(path,options={}){
    const response=await fetch(path,{headers:{"Content-Type":"application/json",...(options.headers||{})},...options});
    let payload={}; try{payload=await response.json()}catch(_){}
    if(!response.ok){const error=new Error(payload.error||`Request failed (${response.status})`);error.status=response.status;throw error}
    return payload;
  };
  window.escapeHTML=function(value){return String(value??"").replace(/[&<>'"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[c]))};
  window.ravenToast=function(message,type="success"){
    const region=document.getElementById("toast-region"); if(!region)return;
    const toast=document.createElement("div"); toast.className=`toast toast-${type}`; toast.textContent=message; region.appendChild(toast);
    setTimeout(()=>toast.remove(),3600);
  };
  if(localStorage.getItem("cyclonex_theme")==="light")root.classList.add("light");
  if(page!=="login"){
    const shell=document.getElementById("app-shell"); if(shell)shell.innerHTML=`<header class="topbar"><a class="brand" href="dashboard.html"><span class="brand-mark">C</span> CYCLONEX</a><button class="mobile-menu" id="mobile-menu" type="button" aria-label="Toggle navigation">☰</button><nav class="nav" aria-label="Primary">${nav.map(n=>`<a class="${page===n[2]?"active":""}" href="${n[0]}">${n[1]}</a>`).join("")}</nav><div class="shell-actions"><button class="icon-btn" id="theme-toggle" type="button" title="Toggle contrast">◐</button><button class="icon-btn" id="logout-btn" type="button" title="Sign out">↪</button><a class="sos-link" href="sos.html">SOS</a></div></header><div id="toast-region" class="toast-region" aria-live="polite"></div>`;
  }
  async function boot(){
    if(page==="login")return;
    try{
      const me=await api("/api/me");
      if(!me.user){window.location.replace("login.html");return}
      window.RAVEN_USER=me.user;
      const data=await api("/api/bootstrap");
      window.RAVEN_DATA=data;
      window.dispatchEvent(new CustomEvent("raven:data-ready",{detail:data}));
    }catch(error){if(error.status===401)window.location.replace("login.html");else ravenToast(error.message,"error")}
  }
  document.addEventListener("DOMContentLoaded",()=>{
    document.getElementById("theme-toggle")?.addEventListener("click",()=>{root.classList.toggle("light");localStorage.setItem("cyclonex_theme",root.classList.contains("light")?"light":"dark");ravenToast(root.classList.contains("light")?"Light contrast enabled":"Dark contrast enabled")});
    document.getElementById("mobile-menu")?.addEventListener("click",()=>document.querySelector(".nav")?.classList.toggle("open"));
    document.getElementById("logout-btn")?.addEventListener("click",async()=>{await api("/api/logout",{method:"DELETE"});window.location.replace("login.html")});
    document.addEventListener("click",e=>{if(e.target.closest(".nav a"))document.querySelector(".nav")?.classList.remove("open")});
    boot();
  });
})();