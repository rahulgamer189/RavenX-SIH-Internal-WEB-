let ravenMap,layers={zones:L.layerGroup(),sos:L.layerGroup(),shelters:L.layerGroup(),rain:L.layerGroup(),track:L.layerGroup()},osmBase,satelliteBase;
function drawMapData(){
 if(!ravenMap||!window.RAVEN_DATA)return;
 Object.values(layers).forEach(layer=>layer.clearLayers());
 const zIcon=r=>L.divIcon({className:"",html:`<div class="leaflet-risk-dot risk-dot-${r.toLowerCase()}"></div>`,iconSize:[18,18],iconAnchor:[9,9]});
 window.RAVEN_DATA.zones.forEach(z=>L.marker([z.lat,z.lng],{icon:zIcon(z.risk)}).bindPopup(`<b>${escapeHTML(z.name)}</b><br>Risk: ${escapeHTML(z.risk)} (${z.level}%)<br>${escapeHTML(z.meta)}`).addTo(layers.zones));
 window.RAVEN_DATA.sos.forEach(s=>L.marker([s.lat,s.lng]).bindPopup(`<b>${escapeHTML(s.name)}</b><br>${escapeHTML(s.status)}`).addTo(layers.sos));
 window.RAVEN_DATA.shelters.forEach(s=>L.marker([s.lat,s.lng]).bindPopup(`<b>${escapeHTML(s.name)}</b><br>Capacity: ${s.capacity}`).addTo(layers.shelters));
 window.RAVEN_DATA.zones.filter(z=>z.risk!=="Low").forEach(z=>L.circle([z.lat,z.lng],{radius:z.risk==="Critical"?900:z.risk==="High"?600:350,color:z.risk==="Critical"?"#ff3d00":z.risk==="High"?"#ff9100":"#ffd740",fillOpacity:.08,weight:1}).addTo(layers.rain));
 const track=(window.RAVEN_DATA.track||[]).map(p=>[p.lat,p.lng]);
 if(track.length){L.polyline(track,{color:"#29b6f6",weight:3,dashArray:"8 7"}).bindPopup("Forecast track • confidence tapers with time").addTo(layers.track);(window.RAVEN_DATA.track||[]).forEach(p=>L.circleMarker([p.lat,p.lng],{radius:6,color:"#29b6f6",fillColor:"#071f2a",fillOpacity:1,weight:2}).bindTooltip(`${escapeHTML(p.label)} · ${Math.round(p.confidence*100)}% confidence`).addTo(layers.track))}
 ["zones","shelters","sos"].forEach(key=>layers[key].addTo(ravenMap));
 const stats=document.getElementById("map-stats");if(stats)stats.innerHTML=`<div class="data-grid"><div class="data-item"><span>Zones</span><b>${window.RAVEN_DATA.zones.length}</b></div><div class="data-item"><span>SOS</span><b>${window.RAVEN_DATA.sos.length}</b></div><div class="data-item"><span>Shelters</span><b>${window.RAVEN_DATA.shelters.length}</b></div><div class="data-item"><span>Track points</span><b>${track.length}</b></div></div><p class="map-note"><span class="status-dot live"></span> Forecast confidence tapers from observed to +18h.</p>`;
}
function initMap(){
 const mapEl=document.getElementById("map");if(!mapEl||!window.L)return;
 ravenMap=L.map(mapEl).setView([20.2961,85.8245],7);
 osmBase=L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{attribution:"© OpenStreetMap contributors",maxZoom:19}).addTo(ravenMap);
 satelliteBase=L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",{attribution:"Tiles © Esri",maxZoom:19});
 drawMapData();
 if(navigator.geolocation)navigator.geolocation.getCurrentPosition(p=>L.circleMarker([p.coords.latitude,p.coords.longitude],{radius:9,color:"#00e676",fillColor:"#00e676",fillOpacity:.8}).bindPopup("<b>Your location</b>").addTo(ravenMap),()=>{});
 document.querySelectorAll("[data-layer]").forEach(c=>c.addEventListener("change",()=>{const key=c.dataset.layer;if(key==="satellite"){if(c.checked){ravenMap.removeLayer(osmBase);satelliteBase.addTo(ravenMap)}else{ravenMap.removeLayer(satelliteBase);osmBase.addTo(ravenMap)}return}const layer=layers[key];if(!layer)return;c.checked?layer.addTo(ravenMap):ravenMap.removeLayer(layer)}));
 const tick=()=>{const t=document.getElementById("map-time");if(t)t.textContent=new Date().toLocaleTimeString()};tick();setInterval(tick,1000);setTimeout(()=>ravenMap.invalidateSize(),120);
}
document.addEventListener("DOMContentLoaded",initMap);
window.addEventListener("raven:data-ready",drawMapData);