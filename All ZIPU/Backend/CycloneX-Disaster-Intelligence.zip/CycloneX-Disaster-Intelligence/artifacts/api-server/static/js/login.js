document.addEventListener("DOMContentLoaded",async()=>{
  try{const me=await api("/api/me");if(me.user){window.location.replace("dashboard.html");return}}catch(_){}
  const form=document.getElementById("login-form"),error=document.getElementById("login-error");
  document.querySelectorAll(".demo-account").forEach(button=>button.addEventListener("click",()=>{
    form.elements.email.value=button.dataset.email;form.elements.password.value=button.dataset.password;form.elements.password.focus();
  }));
  form.addEventListener("submit",async event=>{
    event.preventDefault();error.hidden=true;
    const button=form.querySelector("button[type=submit]");button.disabled=true;button.textContent="AUTHENTICATING…";
    try{await api("/api/login",{method:"POST",body:JSON.stringify({email:form.elements.email.value,password:form.elements.password.value})});window.location.replace("dashboard.html")}
    catch(err){error.textContent=err.message;error.hidden=false}
    finally{button.disabled=false;button.textContent="ENTER COMMAND CENTER"}
  });
});