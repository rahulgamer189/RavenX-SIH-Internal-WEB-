"""CycloneX API and static web server.

The demo deliberately uses only Python's standard library so it can run with
`npm run dev` in a clean VS Code/Replit checkout. SQLite is the persistence
layer for the demo; swap it for Postgres behind the same handlers for launch.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import mimetypes
import os
import secrets
import sqlite3
import time
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse


ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "static"
DATA_DIR = ROOT / "data"
DB_PATH = DATA_DIR / "cyclonex.db"
PORT = int(os.environ.get("PORT", "5000"))
SESSION_TTL = 60 * 60 * 24 * 7
SESSION_SECRET = os.environ.get("SESSION_SECRET", "cyclonex-local-demo-secret")


def utc_now() -> int:
    return int(time.time())


def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 240_000)
    return f"{salt.hex()}${digest.hex()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        salt_hex, digest_hex = encoded.split("$", 1)
        expected = hashlib.pbkdf2_hmac(
            "sha256", password.encode(), bytes.fromhex(salt_hex), 240_000
        ).hex()
        return hmac.compare_digest(expected, digest_hex)
    except (ValueError, TypeError):
        return False


def connect() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    return db


SEED = {
    "users": [
        {
            "email": "admin@cyclonex.demo",
            "password": "CycloneX123!",
            "name": "Aarav Menon",
            "role": "Authority",
        },
        {
            "email": "responder@cyclonex.demo",
            "password": "Responder123!",
            "name": "Maya Rao",
            "role": "Responder",
        },
    ],
    "weather": {
        "temp": 29,
        "feels": 31,
        "condition": "Partly cloudy",
        "humidity": 78,
        "wind": 18,
        "rainChance": 72,
        "forecast": [
            {"day": "NOW", "icon": "⛅", "temp": "29°", "rain": "72%"},
            {"day": "+3H", "icon": "🌧", "temp": "27°", "rain": "84%"},
            {"day": "+6H", "icon": "⛈", "temp": "26°", "rain": "91%"},
        ],
    },
    "zones": [
        {
            "id": 1,
            "name": "Mahanadi Floodplain",
            "risk": "Critical",
            "level": 94,
            "lat": 20.2961,
            "lng": 85.8245,
            "meta": "River level rising",
        },
        {
            "id": 2,
            "name": "Old Town Sector",
            "risk": "High",
            "level": 77,
            "lat": 20.258,
            "lng": 85.84,
            "meta": "Waterlogging reported",
        },
        {
            "id": 3,
            "name": "Airport Corridor",
            "risk": "Medium",
            "level": 48,
            "lat": 20.252,
            "lng": 85.817,
            "meta": "Heavy rainfall",
        },
        {
            "id": 4,
            "name": "Patia Safe Grid",
            "risk": "Low",
            "level": 15,
            "lat": 20.354,
            "lng": 85.819,
            "meta": "Operational",
        },
    ],
    "sos": [
        {
            "id": "S-104",
            "name": "SOS-104",
            "lat": 20.291,
            "lng": 85.835,
            "status": "Unverified",
        },
        {
            "id": "S-105",
            "name": "SOS-105",
            "lat": 20.276,
            "lng": 85.851,
            "status": "Responder assigned",
        },
    ],
    "shelters": [
        {"name": "CycloneX Shelter A", "lat": 20.312, "lng": 85.817, "capacity": 220},
        {"name": "Community Hall B", "lat": 20.337, "lng": 85.846, "capacity": 140},
    ],
    "nearby": [
        {"id": "NODE-07", "name": "Responder 07", "distance": "18 m", "online": True},
        {"id": "NODE-12", "name": "CycloneX Volunteer", "distance": "42 m", "online": True},
        {"id": "NODE-21", "name": "Field Unit 21", "distance": "87 m", "online": False},
        {"id": "NODE-31", "name": "Medical Team", "distance": "124 m", "online": True},
    ],
    "track": [
        {"lat": 17.92, "lng": 87.20, "label": "Observed", "confidence": 0.94},
        {"lat": 18.35, "lng": 86.72, "label": "+6h", "confidence": 0.82},
        {"lat": 18.92, "lng": 86.22, "label": "+12h", "confidence": 0.68},
        {"lat": 19.51, "lng": 85.78, "label": "+18h", "confidence": 0.51},
    ],
    "broadcasts": [
        {
            "id": "B-221",
            "title": "FLASH FLOOD WARNING",
            "message": "Residents near low-lying river corridors should move to designated shelters.",
            "severity": "Critical",
            "area": "Mahanadi corridor",
            "time": "2 min ago",
        },
        {
            "id": "B-220",
            "title": "Heavy rainfall advisory",
            "message": "Avoid unnecessary travel and monitor local evacuation notices.",
            "severity": "High",
            "area": "Bhubaneswar",
            "time": "18 min ago",
        },
    ],
    "reports": [
        {
            "id": "FR-88",
            "location": "Unit-4 Junction",
            "condition": "Road partially submerged; traffic slow.",
            "resources": "Rescue vehicle",
            "severity": "High",
            "time": "6 min ago",
        },
        {
            "id": "FR-87",
            "location": "Patia",
            "condition": "Shelter operational; water and first aid stocked.",
            "resources": "None",
            "severity": "Low",
            "time": "21 min ago",
        },
    ],
    "feed": [
        {"type": "SOS", "title": "New SOS signal received", "body": "SOS-105 • Responder assigned", "time": "NOW"},
        {"type": "WEATHER", "title": "Rainfall intensity rising", "body": "Current estimate 18 mm/hr", "time": "1 min"},
        {"type": "BROADCAST", "title": "Authority broadcast", "body": "Flash flood warning issued", "time": "2 min"},
        {"type": "FIELD", "title": "Field report received", "body": "Unit-4 Junction • Rescue vehicle requested", "time": "6 min"},
    ],
}


def init_db() -> None:
    with connect() as db:
        db.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                name TEXT NOT NULL,
                role TEXT NOT NULL,
                phone TEXT DEFAULT '',
                location TEXT DEFAULT 'Bhubaneswar, Odisha',
                contacts_json TEXT DEFAULT '[]'
            );
            CREATE TABLE IF NOT EXISTS sessions (
                token TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                expires_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS broadcasts (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                message TEXT NOT NULL,
                severity TEXT NOT NULL,
                area TEXT NOT NULL,
                time TEXT NOT NULL,
                created_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS reports (
                id TEXT PRIMARY KEY,
                location TEXT NOT NULL,
                condition TEXT NOT NULL,
                resources TEXT DEFAULT '',
                severity TEXT NOT NULL,
                photo TEXT DEFAULT '',
                time TEXT NOT NULL,
                created_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS sos (
                id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                note TEXT DEFAULT '',
                meeting TEXT DEFAULT '',
                coords TEXT DEFAULT '',
                status TEXT NOT NULL,
                created_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                node_id TEXT NOT NULL,
                text TEXT NOT NULL,
                mine INTEGER NOT NULL,
                time TEXT NOT NULL,
                created_at INTEGER NOT NULL
            );
            """
        )
        if db.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
            for user in SEED["users"]:
                db.execute(
                    "INSERT INTO users(email,password_hash,name,role,location) VALUES(?,?,?,?,?)",
                    (
                        user["email"],
                        hash_password(user["password"]),
                        user["name"],
                        user["role"],
                        "Bhubaneswar, Odisha",
                    ),
                )
        if db.execute("SELECT COUNT(*) FROM broadcasts").fetchone()[0] == 0:
            now = utc_now()
            for item in SEED["broadcasts"]:
                db.execute(
                    "INSERT INTO broadcasts VALUES(?,?,?,?,?,?,?)",
                    (item["id"], item["title"], item["message"], item["severity"], item["area"], item["time"], now),
                )
        if db.execute("SELECT COUNT(*) FROM reports").fetchone()[0] == 0:
            now = utc_now()
            for item in SEED["reports"]:
                db.execute(
                    "INSERT INTO reports VALUES(?,?,?,?,?,?,?,?)",
                    (
                        item["id"],
                        item["location"],
                        item["condition"],
                        item["resources"],
                        item["severity"],
                        "",
                        item["time"],
                        now,
                    ),
                )


def public_user(row: sqlite3.Row | None) -> dict[str, Any] | None:
    if not row:
        return None
    return {
        "id": row["id"],
        "email": row["email"],
        "name": row["name"],
        "role": row["role"],
        "phone": row["phone"],
        "location": row["location"],
        "contacts": json.loads(row["contacts_json"] or "[]"),
    }


def get_session_user(handler: BaseHTTPRequestHandler) -> sqlite3.Row | None:
    cookie = SimpleCookie()
    cookie.load(handler.headers.get("Cookie", ""))
    token = cookie.get("cyclonex_session")
    if not token:
        return None
    with connect() as db:
        row = db.execute(
            """
            SELECT users.* FROM sessions
            JOIN users ON users.id = sessions.user_id
            WHERE sessions.token = ? AND sessions.expires_at > ?
            """,
            (token.value, utc_now()),
        ).fetchone()
    return row


def json_load(value: bytes) -> dict[str, Any]:
    if len(value) > 1_000_000:
        raise ValueError("Request body is too large")
    data = json.loads(value.decode("utf-8") or "{}")
    if not isinstance(data, dict):
        raise ValueError("JSON object expected")
    return data


def bootstrap_for(user: sqlite3.Row) -> dict[str, Any]:
    with connect() as db:
        broadcasts = [dict(row) for row in db.execute("SELECT id,title,message,severity,area,time FROM broadcasts ORDER BY created_at DESC LIMIT 30")]
        reports = [dict(row) for row in db.execute("SELECT id,location,condition,resources,severity,photo,time FROM reports ORDER BY created_at DESC LIMIT 50")]
        sos = [
            {
                "id": row["id"],
                "name": row["id"],
                "lat": 20.291,
                "lng": 85.835,
                "status": row["status"],
            }
            for row in db.execute("SELECT id,status FROM sos ORDER BY created_at DESC LIMIT 20")
        ]
    if not sos:
        sos = SEED["sos"]
    return {
        "user": public_user(user),
        "weather": SEED["weather"],
        "zones": SEED["zones"],
        "sos": sos,
        "shelters": SEED["shelters"],
        "nearby": SEED["nearby"],
        "track": SEED["track"],
        "broadcasts": broadcasts,
        "reports": reports,
        "feed": SEED["feed"],
    }


class CycloneXHandler(BaseHTTPRequestHandler):
    server_version = "CycloneX/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"[{self.log_date_time_string()}] {self.address_string()} {fmt % args}")

    def send_json(self, payload: Any, status: int = 200, headers: dict[str, str] | None = None) -> None:
        raw = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(raw)

    def send_error_json(self, message: str, status: int = 400) -> None:
        self.send_json({"error": message}, status)

    def require_user(self) -> sqlite3.Row | None:
        user = get_session_user(self)
        if not user:
            self.send_error_json("Authentication required", HTTPStatus.UNAUTHORIZED)
        return user

    def read_body(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        return json_load(self.rfile.read(length))

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/favicon.ico":
            self.send_response(HTTPStatus.NO_CONTENT)
            self.end_headers()
            return
        if path == "/api/healthz":
            self.send_json({"status": "ok", "service": "cyclonex-python"})
            return
        if path == "/api/me":
            user = get_session_user(self)
            self.send_json({"user": public_user(user)} if user else {"user": None})
            return
        if path == "/api/demo-accounts":
            self.send_json({"accounts": [{"email": item["email"], "password": item["password"], "role": item["role"]} for item in SEED["users"]]})
            return
        if not path.startswith("/api/"):
            self.serve_static(path)
            return
        user = self.require_user()
        if not user:
            return
        if path == "/api/bootstrap":
            self.send_json(bootstrap_for(user))
            return
        if path == "/api/messages":
            with connect() as db:
                rows = db.execute(
                    "SELECT node_id,text,mine,time FROM messages WHERE user_id=? ORDER BY created_at DESC LIMIT 100",
                    (user["id"],),
                ).fetchall()
            self.send_json({"messages": [dict(row) for row in reversed(rows)]})
            return
        if path == "/api/profile":
            self.send_json({"user": public_user(user)})
            return
        self.send_error_json("Not found", HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        try:
            data = self.read_body()
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            self.send_error_json(str(exc))
            return
        if path == "/api/login":
            email = str(data.get("email", "")).strip().lower()
            password = str(data.get("password", ""))
            with connect() as db:
                user = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
                if not user or not verify_password(password, user["password_hash"]):
                    self.send_error_json("Invalid demo email or password", HTTPStatus.UNAUTHORIZED)
                    return
                token = secrets.token_urlsafe(32)
                db.execute("INSERT INTO sessions VALUES(?,?,?)", (token, user["id"], utc_now() + SESSION_TTL))
            secure = "; Secure" if os.environ.get("COOKIE_SECURE") == "1" else ""
            self.send_json(
                {"user": public_user(user)},
                headers={"Set-Cookie": f"cyclonex_session={token}; HttpOnly; SameSite=Lax; Path=/; Max-Age={SESSION_TTL}{secure}"},
            )
            return
        user = self.require_user()
        if not user:
            return
        if path == "/api/broadcasts":
            required = ["title", "message", "severity", "area"]
            if any(not str(data.get(key, "")).strip() for key in required):
                self.send_error_json("Title, message, severity and area are required")
                return
            item = {
                "id": f"B-{utc_now()}",
                "title": str(data["title"]).strip(),
                "message": str(data["message"]).strip(),
                "severity": str(data["severity"]).strip(),
                "area": str(data["area"]).strip(),
                "time": "JUST NOW",
            }
            with connect() as db:
                db.execute("INSERT INTO broadcasts VALUES(?,?,?,?,?,?,?)", (*item.values(), utc_now()))
            self.send_json(item, HTTPStatus.CREATED)
            return
        if path == "/api/reports":
            required = ["location", "condition", "severity"]
            if any(not str(data.get(key, "")).strip() for key in required):
                self.send_error_json("Location, condition and severity are required")
                return
            item = {
                "id": f"FR-{utc_now()}",
                "location": str(data["location"]).strip(),
                "condition": str(data["condition"]).strip(),
                "resources": str(data.get("resources", "")).strip(),
                "severity": str(data["severity"]).strip(),
                "photo": str(data.get("photo", "")).strip(),
                "time": "JUST NOW",
            }
            with connect() as db:
                db.execute("INSERT INTO reports VALUES(?,?,?,?,?,?,?,?)", (*item.values(), utc_now()))
            self.send_json(item, HTTPStatus.CREATED)
            return
        if path == "/api/sos":
            item = {
                "id": f"SOS-{str(utc_now())[-5:]}",
                "note": str(data.get("note", "")).strip(),
                "meeting": str(data.get("meeting", "")).strip(),
                "coords": str(data.get("coords", "")).strip(),
                "status": "Unverified",
            }
            with connect() as db:
                db.execute(
                    "INSERT INTO sos(id,user_id,note,meeting,coords,status,created_at) VALUES(?,?,?,?,?,?,?)",
                    (item["id"], user["id"], item["note"], item["meeting"], item["coords"], item["status"], utc_now()),
                )
            self.send_json(item, HTTPStatus.CREATED)
            return
        if path == "/api/messages":
            text = str(data.get("text", "")).strip()
            node_id = str(data.get("nodeId", "")).strip()
            if not text or not node_id:
                self.send_error_json("Select a node and enter a message")
                return
            now = time.strftime("%H:%M:%S")
            with connect() as db:
                db.execute("INSERT INTO messages(user_id,node_id,text,mine,time,created_at) VALUES(?,?,?,?,?,?)", (user["id"], node_id, text, 1, now, utc_now()))
            self.send_json({"node_id": node_id, "text": text, "mine": True, "time": now}, HTTPStatus.CREATED)
            return
        self.send_error_json("Not found", HTTPStatus.NOT_FOUND)

    def do_PUT(self) -> None:
        if urlparse(self.path).path != "/api/profile":
            self.send_error_json("Not found", HTTPStatus.NOT_FOUND)
            return
        user = self.require_user()
        if not user:
            return
        try:
            data = self.read_body()
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            self.send_error_json(str(exc))
            return
        name = str(data.get("name", "")).strip()
        if not name:
            self.send_error_json("Name is required")
            return
        contacts = data.get("contacts", [])
        if not isinstance(contacts, list):
            self.send_error_json("Contacts must be a list")
            return
        with connect() as db:
            db.execute(
                "UPDATE users SET name=?,role=?,phone=?,location=?,contacts_json=? WHERE id=?",
                (
                    name,
                    str(data.get("role", "Civilian")).strip(),
                    str(data.get("phone", "")).strip(),
                    str(data.get("location", "")).strip(),
                    json.dumps(contacts),
                    user["id"],
                ),
            )
            updated = db.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
        self.send_json({"user": public_user(updated)})

    def do_DELETE(self) -> None:
        path = urlparse(self.path).path
        if path == "/api/logout":
            cookie = SimpleCookie()
            cookie.load(self.headers.get("Cookie", ""))
            token = cookie.get("cyclonex_session")
            if token:
                with connect() as db:
                    db.execute("DELETE FROM sessions WHERE token=?", (token.value,))
            self.send_json({"ok": True}, headers={"Set-Cookie": "cyclonex_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0"})
            return
        user = self.require_user()
        if not user:
            return
        if path == "/api/sos":
            with connect() as db:
                db.execute("UPDATE sos SET status='Withdrawn' WHERE user_id=? AND status!='Withdrawn'", (user["id"],))
            self.send_json({"ok": True})
            return
        self.send_error_json("Not found", HTTPStatus.NOT_FOUND)

    def serve_static(self, path: str) -> None:
        relative = path.lstrip("/") or "index.html"
        candidate = (STATIC_DIR / relative).resolve()
        if STATIC_DIR not in candidate.parents and candidate != STATIC_DIR:
            self.send_error_json("Not found", HTTPStatus.NOT_FOUND)
            return
        if candidate.is_dir():
            candidate = candidate / "index.html"
        if not candidate.exists() or not candidate.is_file():
            self.send_error_json("Not found", HTTPStatus.NOT_FOUND)
            return
        content = candidate.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", mimetypes.guess_type(str(candidate))[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(content)


def main() -> None:
    init_db()
    server = ThreadingHTTPServer(("0.0.0.0", PORT), CycloneXHandler)
    print(f"CycloneX Python server listening on 0.0.0.0:{PORT}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()