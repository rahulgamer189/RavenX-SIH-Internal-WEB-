---
name: Artifact preview port
description: Port behavior for generated Replit API artifacts and local Python app runs
---

Generated API artifacts can retain a managed workflow environment that injects `PORT=8080`, even when the app's local command defaults to port 5000. The artifact workflow is the source of truth for its preview port.

**Why:** The first preview restart served correctly on 8080 while an explicit 5000 check failed; the managed artifact configuration was still carrying its original port setting.

**How to apply:** Keep local commands and documentation at the standard 5000 web-app port, but inspect the workflow logs for the actual managed port before taking screenshots or debugging a preview.